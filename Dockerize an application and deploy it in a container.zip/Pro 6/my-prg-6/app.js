const express = require('express');
const app = express();
const PORT = 3000;

app.get('/', (req, res) => {
  res.send('Hello, Dockerized World! this is Program 6');
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});